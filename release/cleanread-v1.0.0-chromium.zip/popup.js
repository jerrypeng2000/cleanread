(() => {
  // src/shared/storage.js
  var DEFAULT_SETTINGS = {
    baseUrl: "https://ajkapi.9zos.com",
    appSlug: "cleanread",
    appId: 0,
    accessToken: "",
    userId: 0,
    theme: "auto",
    maxNestedLinks: 20,
    nestedDepth: 1,
    exportFormat: "markdown"
  };
  async function getSettings() {
    const data = await chrome.storage.sync.get({ settings: DEFAULT_SETTINGS });
    return { ...DEFAULT_SETTINGS, ...data.settings || {} };
  }
  async function saveSettings(settings) {
    const merged = { ...DEFAULT_SETTINGS, ...settings };
    await chrome.storage.sync.set({ settings: merged });
    return merged;
  }
  function todayKey() {
    const d = /* @__PURE__ */ new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  async function getLocalQuota() {
    const data = await chrome.storage.local.get({ localQuota: { date: todayKey(), used: 0 } });
    if (!data.localQuota || data.localQuota.date !== todayKey()) {
      return { date: todayKey(), used: 0 };
    }
    return data.localQuota;
  }

  // src/shared/api.js
  function headers(settings) {
    return {
      "Content-Type": "application/json",
      "Authorization": settings.accessToken || ""
    };
  }
  async function resolveAppId(settings) {
    if (settings.appId > 0) return settings;
    if (!settings.appSlug) return settings;
    try {
      const resp = await fetch(`${settings.baseUrl}/api/marketplace/apps/${encodeURIComponent(settings.appSlug)}`);
      if (!resp.ok) return settings;
      const json = await resp.json();
      const id = json?.data?.app?.id;
      if (id) {
        settings.appId = id;
        await saveSettings(settings);
      }
    } catch (err) {
      console.warn("resolveAppId failed", err);
    }
    return settings;
  }
  async function getEntitlement() {
    let settings = await getSettings();
    if (!settings.accessToken) {
      const local = await getLocalQuota();
      const used = local.date === todayKey() ? local.used : 0;
      return {
        free_enabled: true,
        free_daily_quota: 3,
        free_used_today: used,
        free_remaining_today: Math.max(0, 3 - used),
        plugin_monthly_active: false,
        monthly_price_quota: 0,
        monthly_duration_days: 30,
        requires_upgrade: false,
        local: true
      };
    }
    settings = await resolveAppId(settings);
    if (!settings.appId) {
      return {
        free_enabled: true,
        free_daily_quota: 3,
        free_used_today: 0,
        free_remaining_today: 3,
        plugin_monthly_active: false,
        monthly_price_quota: 0,
        monthly_duration_days: 30,
        requires_upgrade: false,
        local: true,
        error: "\u5E94\u7528ID\u672A\u914D\u7F6E"
      };
    }
    const resp = await fetch(`${settings.baseUrl}/api/billing/app-quota?app_id=${settings.appId}`, {
      headers: headers(settings)
    });
    if (!resp.ok) {
      const text = await resp.text();
      throw new Error(`\u67E5\u8BE2\u989D\u5EA6\u5931\u8D25\uFF08${resp.status}\uFF09\uFF1A${text}`);
    }
    const json = await resp.json();
    return { ...json?.data || {}, local: false };
  }
  async function subscribeMonthly() {
    let settings = await getSettings();
    if (!settings.accessToken) {
      throw new Error("\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u8FDE\u63A5 AjkAPI");
    }
    settings = await resolveAppId(settings);
    const resp = await fetch(`${settings.baseUrl}/api/billing/app-subscribe`, {
      method: "POST",
      headers: headers(settings),
      body: JSON.stringify({ app_id: settings.appId })
    });
    const json = await resp.json();
    if (!resp.ok) {
      throw new Error(json?.message || `\u5F00\u901A\u5931\u8D25\uFF08${resp.status}\uFF09`);
    }
    return json?.data;
  }

  // src/popup.js
  var $ = (id) => document.getElementById(id);
  var entitlement = null;
  var collectedLinks = [];
  function showStatus(text) {
    $("statusText").textContent = text;
  }
  function renderQuota() {
    if (!entitlement) return;
    const freeRemaining = entitlement.free_remaining_today ?? entitlement.freeRemainingToday ?? 0;
    const active = entitlement.plugin_monthly_active || entitlement.pluginMonthlyActive || false;
    if (active) {
      $("quotaTitle").textContent = "\u4F1A\u5458\u72B6\u6001";
      $("quotaValue").textContent = "\u5DF2\u5F00\u901A";
      $("quotaState").textContent = "\u4E0D\u9650\u91CF \xB7 \u5168\u90E8\u529F\u80FD\u53EF\u7528";
    } else {
      $("quotaTitle").textContent = "\u4ECA\u65E5\u514D\u8D39\u989D\u5EA6";
      $("quotaValue").textContent = `${freeRemaining} \u7BC7`;
      $("quotaState").textContent = entitlement.local ? "\u672C\u5730\u8BD5\u7528\u6A21\u5F0F" : "\u514D\u8D39\u7248";
    }
  }
  async function refreshEntitlement(silent = false) {
    if (!silent) showStatus("\u6B63\u5728\u8BFB\u53D6\u989D\u5EA6...");
    try {
      entitlement = await getEntitlement();
      renderQuota();
      showStatus(entitlement.local ? "\u672C\u5730\u6A21\u5F0F \xB7 \u672A\u8FDE\u63A5 AjkAPI" : "\u5DF2\u8FDE\u63A5 AjkAPI");
    } catch (err) {
      showStatus(err?.message || "\u8BFB\u53D6\u989D\u5EA6\u5931\u8D25");
    }
  }
  function ensureCanUse(count = 1) {
    if (!entitlement) return false;
    if (entitlement.plugin_monthly_active || entitlement.pluginMonthlyActive) return true;
    if (count > 1) {
      $("upgradePanel").classList.remove("hidden");
      return false;
    }
    const remaining = entitlement.free_remaining_today ?? entitlement.freeRemainingToday ?? 0;
    if (remaining <= 0) {
      $("upgradePanel").classList.remove("hidden");
      return false;
    }
    return true;
  }
  async function openReader(query) {
    const response = await chrome.runtime.sendMessage({ type: "OPEN_READER", query });
    if (!response?.success) {
      throw new Error(response?.message || "\u6253\u5F00\u9605\u8BFB\u5668\u5931\u8D25");
    }
  }
  async function extractCurrent() {
    if (!ensureCanUse(1)) return;
    try {
      showStatus("\u6B63\u5728\u6253\u5F00\u9605\u8BFB\u5668...");
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      await openReader({ mode: "current", tabId: String(tab?.id || "") });
      window.close();
    } catch (err) {
      showStatus(err?.message || "\u63D0\u53D6\u5931\u8D25");
    }
  }
  async function startBatch() {
    const urls = $("batchUrls").value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    if (!urls.length) {
      showStatus("\u8BF7\u5148\u7C98\u8D34\u81F3\u5C11\u4E00\u4E2A\u94FE\u63A5");
      return;
    }
    if (!ensureCanUse(urls.length)) return;
    try {
      await chrome.storage.session.set({ cleanread_batch_urls: urls });
      await openReader({ mode: "batch" });
      window.close();
    } catch (err) {
      showStatus(err?.message || "\u6279\u91CF\u4EFB\u52A1\u5931\u8D25");
    }
  }
  async function collectNestedLinks() {
    try {
      showStatus("\u6B63\u5728\u8BFB\u53D6\u9875\u9762\u94FE\u63A5...");
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const response = await chrome.runtime.sendMessage({ type: "COLLECT_CURRENT_LINKS", query: { tabId: String(tab?.id || "") } });
      if (!response?.success) throw new Error(response?.message || "\u8BFB\u53D6\u94FE\u63A5\u5931\u8D25");
      collectedLinks = response.data || [];
      renderLinkList();
      $("nestedPanel").classList.remove("hidden");
      showStatus(`\u53D1\u73B0 ${collectedLinks.length} \u4E2A\u94FE\u63A5`);
    } catch (err) {
      showStatus(err?.message || "\u8BFB\u53D6\u94FE\u63A5\u5931\u8D25");
    }
  }
  function renderLinkList() {
    const list = $("linkList");
    const max = Number($("maxNestedLinks").value || 20);
    const visible = collectedLinks.slice(0, max);
    list.innerHTML = "";
    for (const link of visible) {
      const item = document.createElement("label");
      item.className = "link-item";
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = true;
      checkbox.dataset.href = link.href;
      const text = document.createElement("span");
      text.className = "link-text";
      text.textContent = link.text || link.href;
      item.append(checkbox, text);
      list.append(item);
    }
    $("linkCount").textContent = `\u663E\u793A ${visible.length}/${collectedLinks.length}`;
  }
  async function startNested() {
    const checked = Array.from($("linkList").querySelectorAll("input:checked")).map((input) => input.dataset.href);
    if (!checked.length) {
      showStatus("\u8BF7\u81F3\u5C11\u52FE\u9009\u4E00\u4E2A\u94FE\u63A5");
      return;
    }
    if (!ensureCanUse(checked.length)) return;
    try {
      await chrome.storage.session.set({
        cleanread_batch_urls: checked,
        cleanread_nested_depth: Number($("nestedDepth").value || 1)
      });
      await openReader({ mode: "nested" });
      window.close();
    } catch (err) {
      showStatus(err?.message || "\u5D4C\u5957\u91C7\u96C6\u5931\u8D25");
    }
  }
  async function subscribe() {
    const button = $("subscribeButton");
    const message = $("upgradeMessage");
    const settings = await getSettings();
    if (!settings.accessToken) {
      message.textContent = "\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u8FDE\u63A5 AjkAPI";
      showStatus("\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u8FDE\u63A5 AjkAPI");
      chrome.runtime.openOptionsPage();
      return;
    }
    button.disabled = true;
    button.textContent = "\u6B63\u5728\u5F00\u901A...";
    message.textContent = "\u6B63\u5728\u4ECE\u4F59\u989D\u6263\u9664\u5E76\u5F00\u901A...";
    try {
      showStatus("\u6B63\u5728\u4ECE\u4F59\u989D\u6263\u9664\u5E76\u5F00\u901A...");
      await subscribeMonthly();
      await refreshEntitlement();
      $("upgradePanel").classList.add("hidden");
      showStatus("\u4F1A\u5458\u5F00\u901A\u6210\u529F");
      message.textContent = "";
    } catch (err) {
      showStatus(err?.message || "\u5F00\u901A\u5931\u8D25");
      message.textContent = err?.message || "\u5F00\u901A\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5 AjkAPI \u8FDE\u63A5\u548C\u4F59\u989D";
    } finally {
      button.disabled = false;
      button.textContent = "2 \u5143/\u6708\uFF0C\u4ECE\u4F59\u989D\u5F00\u901A";
    }
  }
  $("extractCurrent").addEventListener("click", extractCurrent);
  $("toggleBatch").addEventListener("click", () => {
    $("batchPanel").classList.toggle("hidden");
    $("nestedPanel").classList.add("hidden");
  });
  $("collectNested").addEventListener("click", collectNestedLinks);
  $("refreshLinks").addEventListener("click", collectNestedLinks);
  $("startBatch").addEventListener("click", startBatch);
  $("startNested").addEventListener("click", startNested);
  $("subscribeButton").addEventListener("click", subscribe);
  $("openOptions").addEventListener("click", () => chrome.runtime.openOptionsPage());
  $("openReader").addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL("reader.html") });
  });
  $("openAccountPage").addEventListener("click", () => {
    chrome.tabs.create({ url: "https://ajkapi.9zos.com/console/token" });
  });
  document.addEventListener("DOMContentLoaded", async () => {
    await refreshEntitlement();
  });
})();
