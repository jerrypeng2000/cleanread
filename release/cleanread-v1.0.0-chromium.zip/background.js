(() => {
  // src/background.js
  var READER_URL = chrome.runtime.getURL("reader.html");
  function isHttpUrl(url) {
    return /^https?:\/\//i.test(url || "");
  }
  async function getActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
  }
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function openReader(query = {}) {
    const params = new URLSearchParams(query);
    const url = `${READER_URL}?${params.toString()}`;
    await chrome.tabs.create({ url });
  }
  async function resolveTabId(query = {}, sender = {}) {
    if (query.tabId) {
      const id = Number(query.tabId);
      if (Number.isFinite(id) && id > 0) return id;
    }
    if (sender.tab?.id) return sender.tab.id;
    const active = await getActiveTab();
    return active?.id || 0;
  }
  async function collectCurrentSnapshot(query = {}, sender = {}) {
    const tabId = await resolveTabId(query, sender);
    const tab = await chrome.tabs.get(tabId);
    if (!tab || !tab.id || !isHttpUrl(tab.url)) {
      throw new Error("\u5F53\u524D\u9875\u9762\u4E0D\u53EF\u63D0\u53D6");
    }
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const links = Array.from(document.querySelectorAll("a[href]")).map((a) => {
          try {
            return {
              href: new URL(a.href, location.href).href,
              text: (a.textContent || "").trim().slice(0, 120)
            };
          } catch {
            return null;
          }
        }).filter(Boolean);
        return {
          url: location.href,
          title: document.title,
          html: document.documentElement.outerHTML,
          links
        };
      }
    });
    return results[0]?.result;
  }
  async function collectCurrentLinks(query = {}, sender = {}) {
    const tabId = await resolveTabId(query, sender);
    const tab = await chrome.tabs.get(tabId);
    if (!tab || !tab.id || !isHttpUrl(tab.url)) {
      throw new Error("\u5F53\u524D\u9875\u9762\u4E0D\u53EF\u63D0\u53D6");
    }
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const seen = /* @__PURE__ */ new Set();
        return Array.from(document.querySelectorAll("a[href]")).map((a) => {
          try {
            const href = new URL(a.href, location.href).href;
            if (seen.has(href)) return null;
            seen.add(href);
            return { href, text: (a.textContent || "").trim().slice(0, 120) };
          } catch {
            return null;
          }
        }).filter(Boolean);
      }
    });
    return results[0]?.result || [];
  }
  async function fetchPageHtmlViaTab(url) {
    if (!isHttpUrl(url)) throw new Error("\u4EC5\u652F\u6301 http/https \u94FE\u63A5");
    const tab = await chrome.tabs.create({ url, active: false });
    try {
      for (let i = 0; i < 80; i++) {
        await sleep(500);
        const current = await chrome.tabs.get(tab.id);
        if (current.status === "complete") break;
      }
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const links = Array.from(document.querySelectorAll("a[href]")).map((a) => {
            try {
              return {
                href: new URL(a.href, location.href).href,
                text: (a.textContent || "").trim().slice(0, 120)
              };
            } catch {
              return null;
            }
          }).filter(Boolean);
          return {
            url: location.href,
            title: document.title,
            html: document.documentElement.outerHTML,
            links
          };
        }
      });
      return results[0]?.result;
    } finally {
      await chrome.tabs.remove(tab.id);
    }
  }
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "cleanread-extract-page",
      title: "\u7528\u7F51\u9875\u9605\u8BFB\u5668\u63D0\u53D6\u672C\u9875",
      contexts: ["page"]
    });
  });
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === "cleanread-extract-page" && tab?.id) {
      await chrome.tabs.update(tab.id, { active: true });
      await openReader({ mode: "current", tabId: String(tab.id) });
    }
  });
  chrome.commands.onCommand.addListener(async (command) => {
    if (command === "extract-current-page") {
      const tab = await getActiveTab();
      await openReader({ mode: "current", tabId: String(tab?.id || "") });
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
      try {
        if (message?.type === "COLLECT_CURRENT_SNAPSHOT") {
          sendResponse({ success: true, data: await collectCurrentSnapshot(message.query || {}, sender) });
          return;
        }
        if (message?.type === "COLLECT_CURRENT_LINKS") {
          sendResponse({ success: true, data: await collectCurrentLinks(message.query || {}, sender) });
          return;
        }
        if (message?.type === "FETCH_PAGE_HTML") {
          sendResponse({ success: true, data: await fetchPageHtmlViaTab(message.url) });
          return;
        }
        if (message?.type === "OPEN_READER") {
          const query = { ...message.query || {} };
          if (!query.tabId && query.mode === "current") {
            const tabId = await resolveTabId(query, sender);
            if (tabId) query.tabId = String(tabId);
          }
          await openReader(query);
          sendResponse({ success: true });
          return;
        }
        sendResponse({ success: false, message: "\u672A\u77E5\u6D88\u606F\u7C7B\u578B" });
      } catch (err) {
        sendResponse({ success: false, message: err?.message || String(err) });
      }
    })();
    return true;
  });
})();
