(() => {
  // src/content.js
  (function() {
    if (window.top !== window) return;
    if (document.documentElement?.dataset?.cleanreadInjected) return;
    document.documentElement.dataset.cleanreadInjected = "1";
    const host = document.createElement("div");
    host.id = "cleanread-page-button-host";
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
    .cr-btn {
      position: fixed;
      right: 22px;
      bottom: 22px;
      z-index: 2147483647;
      width: 44px;
      height: 44px;
      border: 0;
      border-radius: 50%;
      background: linear-gradient(135deg, #2563eb, #4f46e5);
      color: #fff;
      font-size: 18px;
      font-weight: 700;
      line-height: 1;
      cursor: pointer;
      box-shadow: 0 8px 24px rgba(37, 99, 235, 0.35);
      display: grid;
      place-items: center;
    }
    .cr-btn:hover { transform: translateY(-1px); }
    .cr-btn:active { transform: translateY(0); }
  `;
    const button = document.createElement("button");
    button.className = "cr-btn";
    button.title = "\u7528\u51C0\u8BFBCleanRead\u63D0\u53D6\u672C\u9875";
    button.textContent = "\u8BFB";
    button.addEventListener("click", () => {
      try {
        chrome.runtime.sendMessage({ type: "OPEN_READER", query: { mode: "current" } });
      } catch (_) {
      }
    });
    shadow.append(style, button);
    document.documentElement.appendChild(host);
  })();
})();
