(() => {
  // src/shared/storage.js
  var DEFAULT_SETTINGS = {
    baseUrl: "https://ajkapi.9zos.com",
    appSlug: "cleanread",
    appId: 0,
    accessToken: "",
    userId: 0,
    theme: "auto",
    maxNestedLinks: 20,
    nestedDepth: 1,
    exportFormat: "markdown"
  };
  async function getSettings() {
    const data = await chrome.storage.sync.get({ settings: DEFAULT_SETTINGS });
    return { ...DEFAULT_SETTINGS, ...data.settings || {} };
  }
  async function saveSettings(settings) {
    const merged = { ...DEFAULT_SETTINGS, ...settings };
    await chrome.storage.sync.set({ settings: merged });
    return merged;
  }
  function todayKey() {
    const d = /* @__PURE__ */ new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  async function getLocalQuota() {
    const data = await chrome.storage.local.get({ localQuota: { date: todayKey(), used: 0 } });
    if (!data.localQuota || data.localQuota.date !== todayKey()) {
      return { date: todayKey(), used: 0 };
    }
    return data.localQuota;
  }

  // src/shared/api.js
  function headers(settings) {
    return {
      "Content-Type": "application/json",
      "Authorization": settings.accessToken || ""
    };
  }
  async function resolveAppId(settings) {
    if (settings.appId > 0) return settings;
    if (!settings.appSlug) return settings;
    try {
      const resp = await fetch(`${settings.baseUrl}/api/marketplace/apps/${encodeURIComponent(settings.appSlug)}`);
      if (!resp.ok) return settings;
      const json = await resp.json();
      const id = json?.data?.app?.id;
      if (id) {
        settings.appId = id;
        await saveSettings(settings);
      }
    } catch (err) {
      console.warn("resolveAppId failed", err);
    }
    return settings;
  }
  async function getEntitlement() {
    let settings = await getSettings();
    if (!settings.accessToken) {
      const local = await getLocalQuota();
      const used = local.date === todayKey() ? local.used : 0;
      return {
        free_enabled: true,
        free_daily_quota: 3,
        free_used_today: used,
        free_remaining_today: Math.max(0, 3 - used),
        plugin_monthly_active: false,
        monthly_price_quota: 0,
        monthly_duration_days: 30,
        requires_upgrade: false,
        local: true
      };
    }
    settings = await resolveAppId(settings);
    if (!settings.appId) {
      return {
        free_enabled: true,
        free_daily_quota: 3,
        free_used_today: 0,
        free_remaining_today: 3,
        plugin_monthly_active: false,
        monthly_price_quota: 0,
        monthly_duration_days: 30,
        requires_upgrade: false,
        local: true,
        error: "\u5E94\u7528ID\u672A\u914D\u7F6E"
      };
    }
    const resp = await fetch(`${settings.baseUrl}/api/billing/app-quota?app_id=${settings.appId}`, {
      headers: headers(settings)
    });
    if (!resp.ok) {
      const text = await resp.text();
      throw new Error(`\u67E5\u8BE2\u989D\u5EA6\u5931\u8D25\uFF08${resp.status}\uFF09\uFF1A${text}`);
    }
    const json = await resp.json();
    return { ...json?.data || {}, local: false };
  }
  async function testConnection() {
    const entitlement = await getEntitlement();
    return entitlement;
  }

  // src/options.js
  var $ = (id) => document.getElementById(id);
  async function fillForm() {
    const settings = await getSettings();
    $("baseUrl").value = settings.baseUrl || "";
    $("appSlug").value = settings.appSlug || "";
    $("appId").value = settings.appId || 0;
    $("accessToken").value = settings.accessToken || "";
    $("theme").value = settings.theme || "auto";
    $("exportFormat").value = settings.exportFormat || "markdown";
    $("maxNestedLinks").value = settings.maxNestedLinks || 20;
  }
  async function collectForm() {
    const settings = {
      baseUrl: $("baseUrl").value.trim().replace(/\/$/, ""),
      appSlug: $("appSlug").value.trim(),
      appId: Number($("appId").value || 0),
      accessToken: $("accessToken").value.trim(),
      theme: $("theme").value,
      exportFormat: $("exportFormat").value,
      maxNestedLinks: Math.max(1, Math.min(50, Number($("maxNestedLinks").value || 20)))
    };
    if (!settings.baseUrl) {
      throw new Error("\u670D\u52A1\u5668\u5730\u5740\u4E0D\u80FD\u4E3A\u7A7A");
    }
    return settings;
  }
  async function save() {
    try {
      const settings = await collectForm();
      await saveSettings(settings);
      $("connectionResult").textContent = "\u5DF2\u4FDD\u5B58\u3002";
    } catch (err) {
      $("connectionResult").textContent = err?.message || "\u4FDD\u5B58\u5931\u8D25";
    }
  }
  async function test() {
    try {
      const settings = await collectForm();
      await saveSettings(settings);
      let resolved = await resolveAppId(settings);
      const entitlement = await testConnection();
      const active = entitlement.plugin_monthly_active || entitlement.pluginMonthlyActive;
      const remaining = entitlement.free_remaining_today ?? entitlement.freeRemainingToday ?? 0;
      $("connectionResult").textContent = `\u8FDE\u63A5\u6210\u529F\u3002App ID: ${resolved.appId || "\u672A\u89E3\u6790"}\uFF1B${active ? "\u4F1A\u5458\u5DF2\u5F00\u901A" : `\u4ECA\u65E5\u514D\u8D39\u5269\u4F59 ${remaining} \u7BC7`}\u3002`;
    } catch (err) {
      $("connectionResult").textContent = err?.message || "\u8FDE\u63A5\u5931\u8D25";
    }
  }
  $("saveSettings").addEventListener("click", save);
  $("testConnection").addEventListener("click", test);
  document.addEventListener("DOMContentLoaded", fillForm);
})();
